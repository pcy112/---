document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault(); // 폼 제출 기본 동작 방지

    // 입력값 가져오기
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // 서버로 데이터 전송
    fetch('http://localhost:3000/users', { // 실제 API URL로 변경
        method: 'POST',
        headers: {
            'Content-Type': 'application/json', // JSON 형식으로 전송
        },
        body: JSON.stringify({ username, email, password }), // 데이터 직렬화
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('네트워크 응답이 올바르지 않습니다.');
            }
            return response.json(); // JSON 응답 처리
        })
        .then(data => {
            if (data.success) {
                document.getElementById('message').innerText = '회원가입 성공!';
                // 성공 시 다른 페이지로 이동
                window.location.href = 'welcome.html';
            } else {
                document.getElementById('message').innerText = '회원가입 실패: ' + data.message;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('message').innerText = '회원가입 중 오류가 발생했습니다.';
        });
});